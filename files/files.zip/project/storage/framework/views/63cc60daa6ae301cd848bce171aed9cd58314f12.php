<?php $__env->startSection('content'); ?>

    <section class="container" style="margin-top: 20px;">

        <div class="content-push">

            <div class="breadcrumb-box">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/cart')); ?>">My Cart</a>
            </div>
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(Session::get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="information-blocks">
                <div class="table-responsive">
                    <table class="cart-table">
                        <tr>
                            <th class="column-1">Product Name</th>
                            <th class="column-2">Unit Price</th>
                            <th class="column-3">Qty</th>
                            <th class="column-4">Subtotal</th>
                            <th class="column-5"></th>
                        </tr>
                        <tr id="cartempty"></tr>
                        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="item<?php echo e($cart->product); ?>">
                            <td>
                                <div class="traditional-cart-entry">
                                    <a href="#" class="image"><img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e(\App\Product::findOrFail($cart->product)->feature_image); ?>" alt=""></a>
                                    <div class="content">
                                        <div class="cell-view">
                                            
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($cart->product); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Product::findOrFail($cart->product)->title))); ?>" class="title"><?php echo e($cart->title); ?></a>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td id="price<?php echo e($cart->product); ?>" class="prices">$<?php echo e(\App\Product::findOrFail($cart->product)->first()->price); ?></td>
                            <td>
                                <div class="quantity-selector detail-info-entry">
                                    <div class="entry number-minus" id="minus<?php echo e($cart->product); ?>">&nbsp;</div>
                                    <div class="entry number" id="number<?php echo e($cart->product); ?>"><?php echo e($cart->quantity); ?></div>
                                    <div class="entry number-plus" id="plus<?php echo e($cart->product); ?>">&nbsp;</div>
                                </div>
                            </td>
                            <td><div class="subtotal" id="subtotal<?php echo e($cart->product); ?>">$<?php echo e($cart->cost); ?></div></td>
                            <td><a class="remove-button" onclick="getDelete(<?php echo e($cart->product); ?>)"><i class="fa fa-times"></i></a></td>

                            <form id="citem<?php echo e($cart->product); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php if(Session::has('uniqueid')): ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                <?php endif; ?>
                                <input type="hidden" name="title" value="<?php echo e($cart->title); ?>">
                                <input type="hidden" name="product" value="<?php echo e($cart->product); ?>">
                                <input type="hidden" id="cost<?php echo e($cart->product); ?>" name="cost" value="<?php echo e($cart->cost); ?>">
                                <input type="hidden" id="quantity<?php echo e($cart->product); ?>" name="quantity" value="<?php echo e($cart->quantity); ?>">
                            </form>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>
                                    <h3>Your Cart is Empty.</h3>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        <?php endif; ?>

                    </table>
                </div>
                <div class="cart-submit-buttons-box">
                    <div class="row" style="margin: 0">
                    <div class="cart-summary-box pull-right col-md-6" style="margin: 0">
                        <div class="grand-total">Total <span id="grandtotal">$<?php echo e($sum); ?></span></div>
                        <a class="col-md-6 pull-right button style-10" href="<?php echo e(route('user.checkout')); ?>">Proceed To Checkout</a>
                        <a class="col-md-5 pull-right button style-10" href="<?php echo e(url('/')); ?>">Continue Shopping</a>

                    </div>
                    </div>
                </div>

            </div>


        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>