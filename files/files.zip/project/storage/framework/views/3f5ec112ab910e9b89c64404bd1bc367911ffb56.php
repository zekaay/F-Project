<?php $__env->startSection('content'); ?>

    <div class="home-wrapper">
        <div class="section-padding product-details-wrapper padding-bottom-0 wow fadeInUp">
            <div class="container">
                <div class="product-projects-FullDiv-area">
                    <div class="breadcrumb-box">
                        <a href="<?php echo e(url('/')); ?>"><?php echo e($language->home); ?></a>
                        <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[0])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[0])->first()->name); ?></a>
                        <?php if($productdata->category[1] != ""): ?>
                            <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[1])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[1])->first()->name); ?></a>
                        <?php endif; ?>
                        <?php if($productdata->category[2] != ""): ?>
                            <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[2])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[2])->first()->name); ?></a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($productdata->id); ?>/<?php echo e(str_replace(' ','-',strtolower($productdata->title))); ?>"><?php echo e($productdata->title); ?></a>
                    </div>

                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="product-review-carousel-img product-zoom">
                                <img id="imageDiv" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">
                            </div>
                            <div class="product-review-owl-carousel">
                                <div class="single-product-item">
                                    <img id="iconOne" onclick="productGallery(this.id)" src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($productdata->feature_image); ?>" alt="">
                                </div>
                                <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galdta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="single-product-item">
                                        <img id="galleryimg<?php echo e($galdta->id); ?>" onclick="productGallery(this.id)" src="<?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($galdta->image); ?>" alt="">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <h2 class="product-header"><?php echo e($productdata->title); ?></h2>
                            <?php if($productdata->owner != "admin"): ?>
                                <?php if(\App\Vendors::where('id',$productdata->vendorid)->count() != 0): ?>
                                    <strong class=""><?php echo e($language->vendor); ?>: <a href="<?php echo e(url('/shop')); ?>/<?php echo e($productdata->vendorid); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Vendors::findOrFail($productdata->vendorid)->shop_name))); ?>" target="_blank"><?php echo e(\App\Vendors::findOrFail($productdata->vendorid)->shop_name); ?></a></strong>
                                <?php endif; ?>
                            <?php else: ?>
                            <?php endif; ?>
                            <p class="product-status">
                            <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                <span class="available">
                                    <i class="fa fa-check-square-o"></i>
                                    <span><?php echo e($language->available); ?></span>
                                </span>
                            <?php else: ?>
                                <span class="not-available">
                                <i class="fa fa-times-circle-o"></i>
                                <span><?php echo e($language->out_of_stock); ?></span>
                                </span>
                            <?php endif; ?>

                            </p>
                            <div>
                                <div class="ratings">
                                    <div class="empty-stars"></div>
                                    <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($productdata->id)); ?>%"></div>
                                </div>
                                <?php if(\App\Review::reviewCount($productdata->id) > 1): ?>
                                    <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Reviews</span>
                                <?php else: ?>
                                    <span><?php echo e(\App\Review::reviewCount($productdata->id)); ?> Review</span>
                                <?php endif; ?>
                            </div>
                            <p class="product-description">
                                <?php echo e(substr(strip_tags($productdata->description), 0, 600)); ?>...
                                <a href="">show more</a>
                            </p>
                            <h1 class="product-price">
                                <?php if($productdata->previous_price != ""): ?>
                                    <span>
                                        <del><?php echo e($settings[0]->currency_sign); ?><?php echo e($productdata->previous_price); ?></del>
                                    </span>
                                <?php endif; ?>
                                    <?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Product::Cost($productdata->id)); ?>

                            </h1>

                            <?php if($productdata->sizes != null): ?>
                                <div class="product-size" id="product-size">
                                <p>Size</p>
                                    <?php $__currentLoopData = explode(',',$productdata->sizes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($size); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <div class="product-quantity">
                                <p><?php echo e($language->quantity); ?></p>
                                <span class="quantity-btn" id="qty-minus"><i class="fa fa-minus"></i></span>
                                <span id="pqty">1</span>
                                <span class="quantity-btn" id="qty-add"><i class="fa fa-plus"></i></span>
                            </div>
                            <form class="addtocart-form">
                                <?php echo e(csrf_field()); ?>

                                <?php if(Session::has('uniqueid')): ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                <?php endif; ?>
                                <input type="hidden" id="price" name="price" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                <input type="hidden" name="title" value="<?php echo e($productdata->title); ?>">
                                <input type="hidden" name="product" value="<?php echo e($productdata->id); ?>">
                                <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($productdata->id)); ?>">
                                <input type="hidden" id="quantity" name="quantity" value="1">
                                <input type="hidden" id="size" name="size" value="">
                                <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                    <button type="button" class="product-addCart-btn to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                <?php else: ?>
                                    <button type="button" class="product-addCart-btn  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section-padding product-description-wrapper padding-bottom-0 padding-top-0 wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="custom-tab">
                            <div class="row">
                                <div class="col-md-5">
                                    <ul class="tab-list">
                                        <li class="active"><a data-toggle="tab" href="#overview-tab-1"><?php echo e($language->description); ?></a></li>
                                        <li><a data-toggle="tab" href="#pricing-tab-2"><?php echo e($language->return_policy); ?></a></li>
                                        <li><a data-toggle="tab" href="#location-tab-3"><?php echo e($language->reviews); ?>(<?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?>)</a></li>
                                    </ul>
                                </div>

                                <div class="col-md-7">
                                    <?php if(Session::has('message')): ?>
                                        <div class="alert alert-success alert-dismissable">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <?php echo e(Session::get('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div class="tab-content">
                                        <div id="overview-tab-1" class="tab-pane active fade in">
                                            <p><?php echo $productdata->description; ?></p>
                                        </div>

                                        <div id="pricing-tab-2" class="tab-pane fade">
                                            <p><?php echo $productdata->policy; ?></p>
                                        </div>

                                        <div id="location-tab-3" class="tab-pane fade">
                                            <p>
                                                <h1><?php echo e($language->write_a_review); ?></h1>
                                                <hr>
                                                <div class="review-star">
                                                    <div class='starrr' id='star1'></div>
                                                    <div>
                                                        <span class='your-choice-was' style='display: none;'>
                                                            Your rating is: <span class='choice'></span>.
                                                        </span>
                                                    </div>
                                                </div>
                                                <form class="product-review-form" method="POST" action="<?php echo e(route('review.submit')); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="rating" id="rate" value="5">
                                                    <input type="hidden" name="productid" value="<?php echo e($productdata->id); ?>">
                                                    <div class="form-group">
                                                        <input name="name" type="text" class="form-control" placeholder="<?php echo e($language->name); ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <input name="email" type="email" class="form-control" placeholder="<?php echo e($language->email); ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <textarea name="review" id="" rows="5" placeholder="<?php echo e($language->review_details); ?>" class="form-control" style="resize: vertical;" required></textarea>
                                                    </div>
                                                    <?php if($errors->has('error')): ?>
                                                        <span class="help-block">
                                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                    <div class="form-group text-center">
                                                        <input name="btn" type="submit" class="btn-review" value="<?php echo e($language->submit); ?>">
                                                    </div>
                                                </form>
                                                <hr>
                                                <h1><?php echo e($language->reviews); ?>: </h1>
                                                <hr>
                                                <div class="review-rating-description">
                                                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <div class="row">
                                                        <div class="col-md-3 col-sm-3">
                                                            <p>cej</p>
                                                            <div class="ratings">
                                                                <div class="empty-stars"></div>
                                                                <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                                                            </div>
                                                            <p><?php echo e($review->review_date); ?></p>
                                                        </div>
                                                        <div class="col-md-9 col-sm-9">
                                                            <p><?php echo e($review->review); ?></p>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <h4><?php echo e($language->no_review); ?></h4>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <hr>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <div class="section-padding product-carousel-wrapper wow fadeInUp">
            <div class="container">
                <div class="product-carousel-full-div">
                    <div class="row margin-bottom-0">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2><?php echo e($language->related_products); ?></h2>
                                <hr>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="product-carousel-list">
                                <?php $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-product-carousel-item text-center">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                        <div class="product-carousel-text">
                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                                <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                            </a>
                                            <div class="ratings">
                                                <div class="empty-stars"></div>
                                                <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>
                                            </div>
                                            <div class="product-price">
                                                <?php if($product->previous_price != ""): ?>
                                                    <span class="original-price">$<?php echo e($product->previous_price); ?></span>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <del class="offer-price">$<?php echo e($product->price); ?></del>
                                            </div>
                                            <div class="product-meta-area">
                                                <a href="" class="addTo-cart">
                                                    <i class="fa fa-cart-plus"></i>
                                                    <span>add to cart</span>
                                                </a>
                                                <a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });

    $("#showmore").click(function() {
        $('html, body').animate({
            scrollTop: $("#description").offset().top - 200
        }, 1000);
    });


    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>