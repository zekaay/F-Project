<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1>Search Result For: <?php echo e($search); ?></h1>
                </div>
            </div>

        </div>


    </section>


    <div id="wrapper" class="go-section">
        <section class="wow fadeInUp go-products">
            <div class="container">
                <div class="row">

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-3 product">
                        <article class="col-item">
                            <div class="photo">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                            </div>
                            <div class="info">
                                <div class="row">
                                    <div class="price-details">

                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                            <h1><?php echo e($product->title); ?></h1>
                                        </a>
                                        <div class="pull-left">
                                            <span class="price-old">$<?php echo e($product->previous_price); ?></span>
                                            <span class="price-new">$<?php echo e($product->price); ?></span>
                                        </div>
                                        <div class="pull-right">
                                            <span class="review">
                                                <?php for($i=1;$i<=5;$i++): ?>
                                                    <?php if($i <= \App\Review::where('productid',$product->id)->avg('rating')): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-star-o"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </span>
                                        </div>

                                    </div>

                                </div>
                                <div class="separator clear-left">

                                    <form>
                                        <p>
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Session::has('uniqueid')): ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" id="cost" name="cost" value="<?php echo e($product->price); ?>">
                                        <input type="hidden" id="quantity" name="quantity" value="1">
                                        <?php if($product->stock != 0): ?>
                                            <button type="button" class="button style-10 to-cart">Add to cart</button>
                                        <?php else: ?>
                                            <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                        <?php endif; ?>
                                        
                                        </p>
                                    </form>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </article>



                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3>No Product Found in This Keyword.</h3>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>