<?php $__env->startSection('content'); ?>


<section class="go-slider">
<div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000" >

    <!-- Indicators -->
    
        
            
                
            
                
            
        
    

    <!-- Wrapper For Slides -->
    <div class="carousel-inner" role="listbox">

        <?php for($i = 0; $i < count($sliders); $i++): ?>
            <?php if($i == 0): ?>
                <!-- Third Slide -->
                    <div class="item active">

                        <!-- Slide Background -->
                        <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                        <div class="bs-slider-overlay"></div>

                        <div class="container">
                            <div class="row">
                                <!-- Slide Text Layer -->
                                <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">

                                    <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                                    <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- End of Slide -->
            <?php else: ?>
            <!-- Second Slide -->
                <div class="item">

                    <!-- Slide Background -->
                    <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                    <div class="bs-slider-overlay"></div>
                    <!-- Slide Text Layer -->
                    <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">
                        <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                        <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>
                    </div>
                </div>
                <!-- End of Slide -->
            <?php endif; ?>
    <?php endfor; ?>


    </div><!-- End of Wrapper For Slides -->

        <!-- Left Control -->
        <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <!-- Right Control -->
        <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div> <!-- End  bootstrap-touch-slider Slider -->

</section>

<section class="wow fadeInUp go-services hideme">
    <div class="row" style="margin-top:70px;">
        <div class="container">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                    <h2><?php echo e($languages->service_title); ?></h2>
                    <p><?php echo e($languages->service_text); ?></p>
                </div>
            </div>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-md-4">
                    <div class="service-list text-center wow fadeInUp">
                        <img src="<?php echo e(url('/assets/images/service')); ?>/<?php echo e($service->icon); ?>" alt="">
                        <h3><?php echo e($service->title); ?></h3>
                        <p><?php echo e($service->text); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="wow fadeInUp go-products">
    <div class="container">
        <div class="row">
                <!-- Nav tabs -->
                <div class="card">
                    <div class="col-md-12">
                    <ul class="nav nav-tabs home-tab" role="tablist">
                        <li class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Feature Products</a></li>
                        <li><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"> Latest Products</a></li>
                        <li><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Popular Products</a></li>
                    </ul>
                    </div>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active" id="home">
                                <div class="row">
                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-6 col-sm-4 col-md-3 product">
                                            <article class="col-item">
                                                <div class="photo">
                                                    <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                                                </div>
                                                <div class="info">
                                                    <div class="row">
                                                        <div class="price-details">

                                                            <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                                                <h1><?php echo e($product->title); ?></h1>
                                                            </a>
                                                            <div class="pull-left">
                                                                <?php if($product->previous_price != ""): ?>
                                                                    <span class="price-old">$<?php echo e($product->previous_price); ?></span>
                                                                <?php else: ?>
                                                                <?php endif; ?>
                                                                <span class="price-new">$<?php echo e($product->price); ?></span>
                                                            </div>
                                                            <div class="pull-right">
                                                            <span class="review">
                                                                <?php for($i=1;$i<=5;$i++): ?>
                                                                    <?php if($i <= \App\Review::ratings($product->id)): ?>
                                                                        <i class="fa fa-star"></i>
                                                                    <?php else: ?>
                                                                        <i class="fa fa-star-o"></i>
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </span>
                                                            </div>

                                                        </div>

                                                    </div>
                                                    <div class="separator clear-left">
                                                        <form>
                                                            <p>
                                                                <?php echo e(csrf_field()); ?>

                                                                <?php if(Session::has('uniqueid')): ?>
                                                                    <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                                <?php else: ?>
                                                                    <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                                <?php endif; ?>
                                                                <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                                                <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                                                <input type="hidden" id="cost" name="cost" value="<?php echo e($product->price); ?>">
                                                                <input type="hidden" id="quantity" name="quantity" value="1">
                                                                <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                                    <button type="button" class="button style-10 to-cart">Add to cart</button>
                                                                <?php else: ?>
                                                                    <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                                                <?php endif; ?>
                                                                
                                                            </p>
                                                        </form>

                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </article>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="profile">
                            <div class="row">
                                <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xs-6 col-sm-4 col-md-3 product">
                                        <article class="col-item">
                                            <div class="photo">
                                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                                            </div>
                                            <div class="info">
                                                <div class="row">
                                                    <div class="price-details">

                                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                                            <h1><?php echo e($product->title); ?></h1>
                                                        </a>

                                                        <div class="pull-left prices">
                                                            <?php if($product->previous_price != ""): ?>
                                                                <span class="price-old">$<?php echo e($product->previous_price); ?></span>
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                            <span class="price-new">$<?php echo e($product->price); ?></span>
                                                        </div>
                                                        <div class="pull-right revs">
                                                            <span class="review">
                                                                <?php for($i=1;$i<=5;$i++): ?>
                                                                    <?php if($i <= \App\Review::ratings($product->id)): ?>
                                                                        <i class="fa fa-star"></i>
                                                                    <?php else: ?>
                                                                        <i class="fa fa-star-o"></i>
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </span>
                                                        </div>

                                                    </div>

                                                </div>
                                                <div class="separator clear-left">
                                                    <form>
                                                        <p>
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php if(Session::has('uniqueid')): ?>
                                                                <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                            <?php else: ?>
                                                                <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                            <?php endif; ?>
                                                            <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                                            <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                                            <input type="hidden" id="cost" name="cost" value="<?php echo e($product->price); ?>">
                                                            <input type="hidden" id="quantity" name="quantity" value="1">
                                                            <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                                <button type="button" class="button style-10 to-cart">Add to cart</button>
                                                            <?php else: ?>
                                                                <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                                            <?php endif; ?>
                                                            
                                                        </p>
                                                    </form>

                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </article>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="messages">
                            <div class="row">
                                <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xs-6 col-sm-4 col-md-3 product">
                                        <article class="col-item">
                                            <div class="photo">
                                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                                            </div>
                                            <div class="info">
                                                <div class="row">
                                                    <div class="price-details">

                                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                                            <h1><?php echo e($product->title); ?></h1>
                                                        </a>
                                                        <div class="pull-left">
                                                            <?php if($product->previous_price != ""): ?>
                                                                <span class="price-old">$<?php echo e($product->previous_price); ?></span>
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                            <span class="price-new">$<?php echo e($product->price); ?></span>
                                                        </div>
                                                        <div class="pull-right">
                                                            <span class="review">
                                                                <?php for($i=1;$i<=5;$i++): ?>
                                                                    <?php if($i <= \App\Review::ratings($product->id)): ?>
                                                                        <i class="fa fa-star"></i>
                                                                    <?php else: ?>
                                                                        <i class="fa fa-star-o"></i>
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </span>
                                                        </div>

                                                    </div>

                                                </div>
                                                <div class="separator clear-left">
                                                    <form>
                                                        <p>
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php if(Session::has('uniqueid')): ?>
                                                                <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                                            <?php else: ?>
                                                                <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                                            <?php endif; ?>
                                                            <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                                            <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                                            <input type="hidden" id="cost" name="cost" value="<?php echo e($product->price); ?>">
                                                            <input type="hidden" id="quantity" name="quantity" value="1">
                                                            <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                                <button type="button" class="button style-10 to-cart">Add to cart</button>
                                                            <?php else: ?>
                                                                <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                                            <?php endif; ?>
                                                            
                                                        </p>
                                                    </form>

                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </article>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</section>

<!-- TESTIMONIALS -->
<section class="wow fadeInUp testimonials hideme">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                    <h2><?php echo e($languages->testimonial_title); ?></h2>
                    <p><?php echo e($languages->testimonial_text); ?></p>
                </div>
            </div>
            <div class="col-sm-12">
                <div id="customers-testimonials" class="owl-carousel">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="shadow-effect">
                            <i class="fa fa-quote-right"></i>
                            <div class="item-details">
                                <p class="ctext"><?php echo e($testimonial->review); ?></p>
                                <h5><?php echo e($testimonial->client); ?></h5>
                                <p><?php echo e($testimonial->designation); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END OF TESTIMONIALS -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>