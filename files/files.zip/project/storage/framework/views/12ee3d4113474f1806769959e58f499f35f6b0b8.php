<?php $__env->startSection('content'); ?>

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1>Blog</h1>
                </div>
            </div>

        </div>
    </section>


    <div class="section-padding wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4">
                            <a href="<?php echo e(url('/')); ?>/blog/<?php echo e($blog->id); ?>" class="single-blog-box">
                                <div class="blog-thumb-wrapper">
                                    <img src="assets/images/blog/<?php echo e($blog->featured_image); ?>" alt="Blog Image">
                                </div>
                                <div class="blog-text">
                                    <p class="blog-meta"><?php echo e(date('d M Y',strtotime($blog->created_at))); ?></p>
                                    <h4><?php echo e($blog->title); ?></h4>
                                    <p><?php echo e(substr(strip_tags($blog->details),0,125)); ?></p>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>


    
        
            
                
                    
                    
                        
                            
                                
                            
                            
                                
                                
                                
                            
                        
                    
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>