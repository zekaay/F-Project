<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <?php if(is_object($vendor)): ?>
                        <h1><?php echo e($vendor->shop_name); ?></h1>
                    <?php else: ?>
                        <h1>No Shop Found</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <div id="wrapper" class="go-section">
        <section class="wow fadeInUp go-products">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="products">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xs-6 col-sm-3 product">
                        <article class="col-item">
                            <div class="photo">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                            </div>
                            <div class="info">
                                <div class="row">
                                    <div class="price-details">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                            <h1><?php echo e($product->title); ?></h1>
                                        </a>
                                        <div class="pull-left">
                                            <?php if($product->previous_price != ""): ?>
                                                
                                            <?php else: ?>
                                            <?php endif; ?>
                                            <span class="price-new"><?php echo e(\App\Product::Cost($product->id)); ?> FCFA</span>
                                        </div>
                                        <div class="pull-right">
                                            <span class="review">
                                                <?php for($i=1;$i<=5;$i++): ?>
                                                    <?php if($i <= \App\Review::where('productid',$product->id)->avg('rating')): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-star-o"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </span>
                                        </div>

                                    </div>

                                </div>
                                <div class="separator clear-left">

                                    <form>
                                        <p>
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Session::has('uniqueid')): ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                        <input type="hidden" id="quantity" name="quantity" value="1">
                                        <?php if($product->stock != 0): ?>
                                            <button type="button" class="button style-10 to-cart"><?php echo e($language->add_to_cart); ?></button>
                                        <?php else: ?>
                                            <button type="button" class="button style-10 to-cart" disabled><?php echo e($language->out_of_stock); ?></button>
                                        <?php endif; ?>
                                        
                                        </p>
                                    </form>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3><?php echo e($language->no_result); ?></h3>
                    <?php endif; ?>
                    </div>
                        <?php if(count($products) > 0): ?>
                            <div class="col-sm-12 col-xs-12 col-md-12 text-center" style="margin-top: 15px;">
                                <input type="hidden" id="page" value="2">
                                <div class="col-md-12">
                                <img id="load" src="<?php echo e(url('/assets/images')); ?>/default.gif" style="display: none;width: 80px;"></div>
                                <button type="button" id="load-more" class="button style-3">Load More</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

    $("#load-more").click(function () {
        $("#load").show();
        var id = "<?php echo e($vendor->id); ?>";
        var page = $("#page").val();
        $.get("<?php echo e(url('/')); ?>/loadvendor/"+id+"/"+page, function(data, status){
            $("#load").fadeOut();
            $("#products").append(data);
            //alert("Data: " + data + "\nStatus: " + status);
            $("#page").val(parseInt($("#page").val())+1);
            if ($.trim(data) == ""){
                $("#load-more").fadeOut();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>