<?php $__env->startSection('content'); ?>

    <div class="home-wrapper">
        <!-- Starting of add to cart table -->
        <div class="section-padding product-shoppingCart-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12">

                        <div class="table-responsive">
                            <div class="breadcrumb-box">
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                                <a href="<?php echo e(url('/cart')); ?>">My Cart</a>
                            </div>
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Remove</th>
                                    <th>Image</th>
                                    <th width="25%"><?php echo e($language->product_name); ?></th>
                                    <th><?php echo e($language->quantity); ?></th>
                                    <th><?php echo e($language->unit_price); ?></th>
                                    <th><?php echo e($language->subtotal); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="item<?php echo e($cart->product); ?>">
                                    <td><a onclick="getDelete(<?php echo e($cart->product); ?>)"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                                    <td><img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e(\App\Product::findOrFail($cart->product)->feature_image); ?>" alt=""></td>
                                    <td>
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($cart->product); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Product::findOrFail($cart->product)->title))); ?>" class="product-name-header"><?php echo e($cart->title); ?></a>
                                        <p class="table-product-review">
                                            <i class="fa fa-star"></i>
                                            <span>(06 Reviews)</span>
                                        </p>
                                    </td>
                                    <td>
                                        <p class="cart-btn">
                                            <span class="quantity-cart-minus" id="minus<?php echo e($cart->product); ?>"><i class="fa fa-minus"></i></span>
                                            <span id="number<?php echo e($cart->product); ?>"><?php echo e($cart->quantity); ?></span>
                                            <span class="quantity-cart-plus" id="plus<?php echo e($cart->product); ?>"><i class="fa fa-plus"></i></span>
                                        </p>
                                    </td>
                                    <form id="citem<?php echo e($cart->product); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Session::has('uniqueid')): ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="title" value="<?php echo e($cart->title); ?>">
                                        <input type="hidden" name="product" value="<?php echo e($cart->product); ?>">
                                        <input type="hidden" id="cost<?php echo e($cart->product); ?>" name="cost" value="<?php echo e($cart->cost); ?>" autocomplete="off">
                                        <input type="hidden" id="quantity<?php echo e($cart->product); ?>" name="quantity" value="<?php echo e($cart->quantity); ?>">
                                    </form>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="price<?php echo e($cart->product); ?>"><?php echo e(\App\Product::Cost($cart->product)); ?></span></td>
                                    <td><?php echo e($settings[0]->currency_sign); ?><span id="subtotal<?php echo e($cart->product); ?>" class="subtotal"><?php echo e($cart->cost); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6">
                                            <h3><?php echo e($language->empty_cart); ?></h3>
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                <tr style="border-top: 1px solid black;">
                                    <td colspan="5" style="text-align: right;">
                                        <h3><?php echo e($language->total); ?></h3>
                                    </td>
                                    <td colspan="2" style="text-align: right;">
                                        <h3><?php echo e($settings[0]->currency_sign); ?><span id="grandtotal"><?php echo e(round($sum,2)); ?></span></h3>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <a href="<?php echo e(url('/')); ?>" class="shopping-btn"><?php echo e($language->continue_shopping); ?></a>
                                    </td>
                                    <td colspan="4">
                                        <a href="<?php echo e(route('user.checkout')); ?>" class="update-shopping-btn"><?php echo e($language->proceed_to_checkout); ?></a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of add to cart table -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>