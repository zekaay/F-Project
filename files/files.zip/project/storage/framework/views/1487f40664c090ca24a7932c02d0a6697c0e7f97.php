<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="keywords" content="<?php echo e($code[0]->meta_keys); ?>">
    <meta name="author" content="GeniusOcean">
    <title><?php echo e($settings[0]->title); ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(URL::asset('assets/css/genius1.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/genius-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/genius-gallery.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/lightbox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/animate.min.css')); ?>" rel="stylesheet">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    
</head>
<body>
<div id="cover"></div>
<div class="theme2">
    <div class="row">
        <div class="pull-left gologo">
            <a href="<?php echo e(url('/')); ?>"><img class="img-responsive" src="<?php echo e(URL::asset('assets/images/logo')); ?>/<?php echo e($settings[0]->logo); ?>" alt="Lawyer Directory"></a>
        </div>

        <div class="pull-right headad">
            <div class="desktop-advert">
            <?php if(!empty($ads728x90)): ?>
                <?php if($ads728x90->type == "banner"): ?>
                    <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                        <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                    </a>
                <?php else: ?>
                    <?php echo $ads728x90->script; ?>

                <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>

    </div>

    <nav class="navbar navbar-bootsnipp " role="navigation" id="nav_bar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="animbrand">
                    <div class="navbar-brand" href=""></div>
                </div>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(url('/')); ?>" class="">Home</a></li>
                    <?php if($pagesettings[0]->a_status == 1): ?>
                        <li><a href="<?php echo e(url('/about')); ?>" class="">About Us</a></li>
                    <?php endif; ?>
                    <?php if($pagesettings[0]->f_status == 1): ?>
                        <li><a href="<?php echo e(url('/faq')); ?>" class="">FAQ</a></li>
                    <?php endif; ?>
                    <?php if($pagesettings[0]->c_status == 1): ?>
                        <li><a href="<?php echo e(url('/contact')); ?>" class="">Contact Us</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>



    <?php echo $__env->yieldContent('content'); ?>

<footer>

    <div class="go-top">
        <a id="gtop" href="javascript:;"><i class="fa fa-angle-up"></i></a>
    </div>

<div class="row">
    <div class="col-md-3 about">
        <h4>About Us</h4>
        <p><?php echo e($settings[0]->about); ?></p>
    </div>
    <div class="col-md-3 address">
        <h4>Address</h4>
        <p>Street Address: <?php echo e($settings[0]->address); ?></p>
        <p>Phone: <?php echo e($settings[0]->phone); ?></p>
        <p>Fax:  <?php echo e($settings[0]->fax); ?></p>
        <p>Email: <?php echo e($settings[0]->email); ?></p>
    </div>
    <div class="col-md-3">
        <div class="socicon text-center">
                        <?php if($sociallinks[0]->f_status == "enable"): ?>
                            <a href="<?php echo e($sociallinks[0]->facebook); ?>" class="facebook"><i class="fa fa-facebook"></i></a>
                        <?php endif; ?>
                        <?php if($sociallinks[0]->t_status == "enable"): ?>
                            <a href="<?php echo e($sociallinks[0]->twiter); ?>" class="twitter"><i class="fa fa-twitter"></i></a>
                        <?php endif; ?>
                        <?php if($sociallinks[0]->g_status == "enable"): ?>
                            <a href="<?php echo e($sociallinks[0]->g_plus); ?>" class="google"><i class="fa fa-google"></i></a>
                        <?php endif; ?>
                        <?php if($sociallinks[0]->link_status == "enable"): ?>
                            <a href="<?php echo e($sociallinks[0]->linkedin); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a>
                        <?php endif; ?>
                    </div>
    </div>      
    <div class="col-md-3 text-center">
        <form action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <h4>Subscription:</h4>
            <input type="text" id="email" class="form-control" placeholder="Enter Email" name="email" required>
            <p id="resp">
            <?php if(Session::has('subscribe')): ?>

                    <?php echo e(Session::get('subscribe')); ?>

            <?php endif; ?>
            </p>
            <button id="subs" class="btn btn-ocean">Subscribe</button>
        </form>
    </div>
</div>
      

<div class="c-line"></div>


            <div class="text-center">
                <?php echo $settings[0]->footer; ?>

            </div>

</footer>
</div>
    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.smooth-scroll.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(URL::asset('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets/js/jquery.mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/genius.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/genius-slider.js')); ?>"></script>
    <?php echo $code[0]->google_analytics; ?>

    <?php echo $__env->yieldContent('footer'); ?>
    
    <script>
              new WOW().init();
    </script>
<script>

	$(window).load(function(){
                setTimeout(function(){
                $('#cover').fadeOut(1000);
                },1000)
            });


    $(document).ready(function(){

        $('.project_list').mixItUp({
            animation: {
                effects: 'fade translateZ(-100px)'
            }
        });
    });

    jQuery(document).ready(function($) {
        "use strict";
        $('#customers-testimonials').owlCarousel( {
            loop: true,
            center: true,
            items: 3,
            margin: 30,
            autoplay: true,
            dots:true,
            nav:true,
            autoplayTimeout: 8500,
            smartSpeed: 450,
            navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 2
                },
                1170: {
                    items: 3
                }
            }
        });
    });
</script>
</body>
</html>